public class Quadrado extends Forma {

    private static double lado;

    public Quadrado() {
    }

    public static double getLado() {
        return lado;
    }

    public static void setLado(double lado) {
        Quadrado.lado = lado;
    }



    @Override
    public void getArea() {
        System.out.println("Area quadrado: "+(lado*lado));
    }

    @Override
    public void getPerimetro() {
        System.out.println("Perimetro quadrado: "+(lado *4));
    }


}
