public class GeometriaTeste{


    public static void main(String[] args) {
        double raio = Double.parseDouble(args[0]);
        double comprimento = Double.parseDouble(args[1]);
        double largura = Double.parseDouble(args[2]);
        double lado =Double.parseDouble(args[3]);

        Circulo circulo = new Circulo();
        Quadrado quadrado = new Quadrado();
        Retangulo retangulo = new Retangulo();

        circulo.setRaio(raio);
        circulo.getArea();
        circulo.getPerimetro();
        retangulo.setComprimento(comprimento);
        retangulo.setLargura(largura);
        retangulo.getArea();
        retangulo.getPerimetro();
        quadrado.setLado(lado);
        quadrado.getArea();
        quadrado.getPerimetro();
    }
}