public abstract class Forma {


    public abstract void getArea();


    public abstract void getPerimetro();
}
