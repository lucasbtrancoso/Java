public class Retangulo extends Forma{
    private static double comprimento;
    private static double largura;

    public Retangulo() {
    }



    public static double getComprimento() {
        return comprimento;
    }

    public static void setComprimento(double comprimento) {
        Retangulo.comprimento = comprimento;
    }

    public static double getLargura() {
        return largura;
    }

    public static void setLargura(double largura) {
        Retangulo.largura = largura;
    }

    @Override
    public void getArea() {
        System.out.println("Area retangulo: "+(largura*comprimento));
    }

    @Override
    public void getPerimetro() {
        System.out.println("Perimetro retangulo: "+((largura*2)+(comprimento*2)));
    }




}
