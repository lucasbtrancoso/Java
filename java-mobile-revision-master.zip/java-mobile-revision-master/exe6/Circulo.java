public class Circulo extends Forma {



    private static double raio;

    public Circulo() {
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    @Override
    public void getArea() {
        System.out.println("Area circulo: "+(Math.PI*(raio*raio)));
    }

    @Override
    public void getPerimetro() {
        System.out.println("Perimetro circulo: "+(2*Math.PI)*raio);
    }


}