
public class Retangulo {

    private double comprimento = 1;
    private double largura = 1;

    public double getComprimento() {
        return comprimento;
    }

    public void setComprimento(double comprimento) {
        if (comprimento > 0) {
            this.comprimento = comprimento;
        } else {
            System.out.println("Erro: Um dos lados do retângulo é igual ou menor que zero.");
            System.exit(0);
        }
    }

    public double getLargura() {
        return largura;
    }

    public void setLargura(double largura) {
        if (largura > 0) {
            this.largura = largura;
        } else {
            System.out.println("Erro: Um dos lados do retângulo é igual ou menor que zero.");
            System.exit(0);
        }
    }

    public double calcPerimetro(Retangulo ret) {
        return (ret.largura + ret.comprimento) * 2;
    }

    public double calcArea(Retangulo ret) {
        return ret.largura * ret.comprimento;
    }

    public static void main(String[] args) {
        Retangulo RetanguloTeste = new Retangulo();
        RetanguloTeste.setComprimento(Double.parseDouble(args[0]));
        RetanguloTeste.setLargura(Double.parseDouble(args[1]));

        System.out.println(RetanguloTeste.calcArea(RetanguloTeste));
        System.out.println(RetanguloTeste.calcPerimetro(RetanguloTeste));

    }
}
