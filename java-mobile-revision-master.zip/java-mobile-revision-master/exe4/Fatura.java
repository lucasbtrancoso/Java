public class Fatura {

    public static void main(String[] args) {

        int cod = Integer.valueOf(args[0]);
        String desc = args[1];
        int qtd = Integer.valueOf(args[2]);
        double price = Double.parseDouble(args[3]);
        double total = qtd * price;
        
        System.out.println("Código: " + cod);
        System.out.println("Descriçao: " + desc);
        System.out.println("Quantidade: " + qtd);
        System.out.println("Preço Unitário: " + price);
        System.out.println("Total: " + total);

    }

}
