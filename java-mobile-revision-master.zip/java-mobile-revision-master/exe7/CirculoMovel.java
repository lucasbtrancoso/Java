public class CirculoMovel extends PontoMovel implements Movel{

    private int raio;

    public CirculoMovel(int x, int y, int velX, int velY, int raio){
        super(x, y, velX, velY);
        this.raio = raio;
    }

    @Override
    public void moverParaCima(){

        System.out.println("Movendo Para Cima");

        this.y += this.velY;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaBaixo(){

        System.out.println("Movendo Para Baixo");

        this.y -= this.velY;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaEsquerda(){

        System.out.println("Movendo Para Esquerda");

        this.x += this.velX;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaDireita(){

        System.out.println("Movendo Para Direita");

        this.x -= this.velX;

        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "PontoMovel{" +
                "x=" + x +
                ", y=" + y +
                ", velX=" + velX +
                ", velY=" + velY +
                '}';
    }
}