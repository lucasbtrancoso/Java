public class PontoMovel implements Movel{

    protected int x;
    protected int y;
    protected int velX;
    protected int velY;

    PontoMovel(int x, int y, int velX, int velY){
        this.x = x;
        this.y = y;
        this.velX = velX;
        this.velY = velY;
    }

    public void moverParaCima(){ }

    public void moverParaBaixo(){ }

    public void moverParaEsquerda(){ }

    public void moverParaDireita(){ }
}