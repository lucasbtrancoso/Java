public class FigurasMoveis {

    public static void main(String[] args){

        PontoMovel object = null;

        switch (args[0]){
            case "c":
                object = new CirculoMovel(Integer.parseInt(args[1]),
                        Integer.parseInt(args[2]), Integer.parseInt(args[3]),
                        Integer.parseInt(args[4]), Integer.parseInt(args[5]));
                break;
            case "r":
                object = new Retangulo(Integer.parseInt(args[1]),
                        Integer.parseInt(args[2]), Integer.parseInt(args[3]),
                        Integer.parseInt(args[4]), Integer.parseInt(args[1]),
                        Integer.parseInt(args[2]), Integer.parseInt(args[3]),
                        Integer.parseInt(args[4]));
                break;
        }

        System.out.println(object.toString());

        object.moverParaCima();
        object.moverParaBaixo();
        object.moverParaEsquerda();
        object.moverParaDireita();
    }
}
