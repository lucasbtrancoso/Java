public class Retangulo extends PontoMovel implements Movel{

    private int x2;
    private int y2;
    private int velX2;
    private int velY2;

    public Retangulo(int x, int y, int velX, int velY,int x2, int y2, int velX2, int velY2){
        super(x, y, velX, velY);
        this.x2 = x2;
        this.y2 = y2;
    }

    @Override
    public void moverParaCima(){

        System.out.println("Movendo Para Cima");

        this.y += this.velY;
        this.y2 += this.velY;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaBaixo(){

        System.out.println("Movendo Para Baixo");

        this.y -= this.velY;
        this.y2 -= this.velY;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaEsquerda(){

        System.out.println("Movendo Para Esquerda");

        this.x += this.velX;
        this.x2 += this.velX;

        System.out.println(this.toString());
    }

    @Override
    public void moverParaDireita(){

        System.out.println("Movendo Para Direita");

        this.x -= this.velX;
        this.x2 -= this.velX;

        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "PontoMovel{" +
                "x=" + x +
                ", y=" + y +
                ", velX=" + velX +
                ", velY=" + velY +
                '}';
    }
}