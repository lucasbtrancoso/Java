public interface Movel{

    public void moverParaCima();
    public void moverParaBaixo();
    public void moverParaEsquerda();
    public void moverParaDireita();
}