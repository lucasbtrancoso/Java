class PopulacaoMundial {
	public static void main(String args[]){
		int key = Integer.valueOf(args[0]);
		long currentPop = 7687211830L;
		for(int x = 0; x < key; x++){
			currentPop += ((currentPop*1.04)/100);
		}
		System.out.println("A população daqui a " + key + " será de " + currentPop + " pessoas");
	}
}
