public class CalculaPi{

    public static void main(String[] args) {
      float soma = 0;
        int mult = 1;
        double erro;
        int limit = Integer.parseInt(args[0]);
        for(int i =1; i <= limit ; i += 2 ){

            soma += (mult * (1.0/i));

            mult *= -1;
        }
        soma *= 4;

        erro = ((1-(soma/Math.PI))*100);

        System.out.println("O valor de pi é " + soma);
        System.out.println("Erro: " + erro);

    }
}