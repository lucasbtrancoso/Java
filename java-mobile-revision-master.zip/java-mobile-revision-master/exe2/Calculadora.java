public class Calculadora {
    public static void main(String[] args) {
        
      
        int n1 = Integer.valueOf(args[0]);
        int n2 = Integer.valueOf(args[1]);
        
        System.out.println("Soma: " + (n1 + n2));
        System.out.println("Produto: " + (n1 * n2));
        System.out.println("Diferença: " + (n1 - n2));
        System.out.println("Divisão: " + (n1 / n2));
        System.out.println(n1 > n2 ? n1 + " é maior" : n2 + " é maior");
    }
    
}
