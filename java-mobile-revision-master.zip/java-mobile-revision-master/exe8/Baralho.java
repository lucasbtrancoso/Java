import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baralho {

    private List<Carta> monte;
    //private Integer cartaAtual;
    //private static final Integer TOTAL_DE_CARTAS = 52;
    private static final String[] VALORES = new String[]{"As", "Dois", "Tres", "Quatro",
                                                        "Cinco", "Seis", "Sete", "Oito",
                                                        "Nove", "Dez", "Valete", "Dama", "Rei"};
    private static final String[] NAIPES = new String[]{"Paus", "Ouros", "Copas", "Espadas"};

    public Baralho(){
        setCards();
    }

    private void setCards(){

        monte = new ArrayList<Carta>();

        for (String V: VALORES) {
            for (String N: NAIPES) {

                monte.add(new Carta(N, V));
            }
        }
    }

    public void Embaralhar(){

        System.out.println("Embaralhando Monte");

        Collections.shuffle(monte);
    }

    public void Distribuir(){

        for (Carta c: monte) {

            System.out.println("Ditribuindo " + c);
        }

        System.out.println("Nenhuma Carta No Baralho");
    }
}
