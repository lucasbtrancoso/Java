public class Main {

    public static void main(String[] args) throws InterruptedException {

        Baralho baralho = new Baralho();

        baralho.Embaralhar();
        baralho.Embaralhar();

        baralho.Distribuir();

        Thread.sleep(1000);
    }
}
